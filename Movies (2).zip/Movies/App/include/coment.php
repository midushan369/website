
<?php if(isset($_SESSION['type'])) :?>  
  <?php if($_SESSION['type'] ==='success') :?>   
    <a href="Comment/index.php" class="movie-list-item-button">Comment</a>
  <?php endif; ?>
 <?php endif; ?>